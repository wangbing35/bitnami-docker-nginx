'use strict';

const _ = require('lodash');

$app.helpers.httpoxyPatch = function() {
  // Unset HTTP_PROXY header to protect vs HTTPPOXY vulnerability
  // Ref: https://www.digitalocean.com/community/tutorials/how-to-protect-your-server-against-the-httpoxy-vulnerability
  $file.append($file.join($app.confDir, 'fastcgi_params'), '# Unset the HTTP_PROXY header');
  $file.append($file.join($app.confDir, 'fastcgi_params'), 'fastcgi_param  HTTP_PROXY         "";');
};

$app.helpers.updatePorts = function() {
  _.each([$app.confFile, $file.join($app.confDir, 'server_blocks', 'https.conf')], function(confFile) {
    $file.substitute(confFile, [{
      pattern: /(listen\s+)[0-9]{1,5};/,
      value: `$1${$app.httpPort};`,
    }, {
      pattern: /(listen\s+)[0-9]{1,5}\s+ssl;/,
      value: `$1${$app.httpsPort} ssl;`,
    }], {abortOnUnmatch: true, type: 'regexp', global: false});
  });
};

$app.helpers.updateSpawningUser = function() {
  $file.substitute($app.confFile, [{
    pattern: /^(\s*user\s+)\w+\s+\w+;/m,
    value: `$1${$app.systemUser} ${$app.systemGroup};`,
  }], {abortOnUnmatch: true, type: 'regexp', global: false});
};
