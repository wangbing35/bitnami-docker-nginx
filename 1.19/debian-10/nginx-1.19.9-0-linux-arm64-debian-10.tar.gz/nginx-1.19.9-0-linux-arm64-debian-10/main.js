'use strict';

const _ = require('lodash');
const componentFunctions = require('./lib/component')($app);

$app.postUnpackFiles = function() {
  _.each([$app.confDir, `${$app.confDir}/server_blocks`, $app.tmpDir], function(folder) {
    $file.mkdir(folder);
    componentFunctions.configurePermissions([folder], {mod: {directory: '775', file: '664'}});
  });
  $app.debug('==> Unsetting HTTP_PROXY header...');
  $app.helpers.httpoxyPatch();
  componentFunctions.createExtraConfigurationFiles([
    {type: 'monit', path: $app.monitFile, params: {service: 'nginx', pidFile: $app.pidFile}},
    {type: 'logrotate', path: $app.logrotateFile, params: {logPath: $file.join($app.logsDir, '*log')}},
  ]);
};

$app.postInstallation = function() {
  if (componentFunctions.isProcessRunningAsRoot()) {
    $os.addGroup($app.systemGroup);
    $os.addUser($app.systemUser, {gid: $app.systemGroup});
    $app.helpers.updateSpawningUser();
    componentFunctions.configurePermissions(
      [$app.tmpDir],
      {user: $app.systemUser, group: $app.systemGroup}
    );
  }
  if ($app.enableCustomPorts === 'yes') {
    $app.helpers.updatePorts();
  }
};
